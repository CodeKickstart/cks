import classes from './logo.module.css';

function Logo() {
  return <div className={classes.logo}>NextJS Basics</div>;
}
export default Logo;
